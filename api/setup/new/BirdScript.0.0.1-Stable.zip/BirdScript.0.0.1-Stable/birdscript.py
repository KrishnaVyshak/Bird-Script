# Don't edit the raw python file.
#it may currupt birdscript

import foolscript as run
import sys
from termcolor import colored, cprint

CRED = '\033[91m'
CEND = '\033[0m'



if len(sys.argv) > 1:
    if sys.argv[1] == "--version":
        print("varsion 0.0.1 alpha not stable")
    elif sys.argv[1] == "-r":
        if len(sys.argv) > 2:
            fn = sys.argv[2]
            text = 'RUN("'+ str(fn) + '")'

            result, error = run.run('<stdin>', text)

            if error:
                print(error.as_string())
            elif result:
                if len(result.elements) == 1:
                    print(repr(result.elements[0]))
                else:
                    print(repr(result))
        else:
             print(CRED + "No file specified to run" + CEND)
    elif sys.argv[1] != "--version":
        print(CRED + "Unknown command. Try --version" + CEND)
            
    
else:
    while True:
        text = input('>>> ')
        if text.strip() == "": continue
        result, error = run.run('<stdin>', text)

        if error:
            print(error.as_string())
        elif result:
            if len(result.elements) == 1:
                print(repr(result.elements[0]))
            else:
                print(repr(result))

