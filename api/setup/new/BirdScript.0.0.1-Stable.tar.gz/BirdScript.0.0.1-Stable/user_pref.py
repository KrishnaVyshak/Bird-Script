working_project_directory = "E:/Krishnavyshak/BirdScript.0.0.1-Stable/yourprojects/"

if __name__ == '__main__':
    print("Please Run Birdsctipt.py or Birdscript.pyc or bs.py")
