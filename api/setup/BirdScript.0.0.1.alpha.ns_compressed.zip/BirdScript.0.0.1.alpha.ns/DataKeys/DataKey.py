# Don't edit/delete the content in the file, 
#It may corrupt Bird Script, 
# And you may need to delete and reinstall Bird Script.
# Content Keys ['not to be modified'].

# Projects Path token
project_dir = './YourProjects/'
spec_class = '15oth0m4j'
